	{
		"COLUMNS":["CONTEXT","X_BAR_LABEL","X_BAR_VALUE","TOOL_TIP_TITLE"],
		"DATA":[
		["Staff","Mary",300,"Store 11 [Mary] ^ "],
		["Staff","Louise",400,"Store 11 [Louise] ^ "],
		["Staff","Sue",500,"Store 11 [Sue] ^ "]
		]
	}
