{
	"COLUMNS":["CONTEXT","X_BAR_LABEL","X_BAR_VALUE","TOOL_TIP_TITLE"],
	"DATA":[
	["Staff","Tom",200,"Store 10 [Tom] ^ "],
	["Staff","Dick",300,"Store 10 [Dick] ^ "],
	["Staff","Harry",500,"Store 10 [Harry] ^ "]
	]
}
