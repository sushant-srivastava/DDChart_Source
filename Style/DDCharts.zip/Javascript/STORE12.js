{
	"COLUMNS":["CONTEXT","X_BAR_LABEL","X_BAR_VALUE","TOOL_TIP_TITLE"],
	"DATA":[
	["Staff","Rich",300,"Store 12 [Rich] ^ "],
	["Staff","Chris",500,"Store 12 [Chris] ^ "],
	["Staff","Bill",600,"Store 12 [Bill] ^ "]
	]
}
